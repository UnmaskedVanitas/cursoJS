cantidad = document.querySelector('#cantidad');
color = document.querySelector('#color');
precio = document.querySelector('#precio');
preciototal = document.querySelector('#preciototal');
totalcantidad = document.querySelector('#totalcantidad');
colorfinal = document.querySelector('.color-circle');